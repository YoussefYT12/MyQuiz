﻿using AutoMapper;
using MyQuiz.Appliction.Contracts.IRepositories.IQuiz;
using MyQuiz.Appliction.Contracts.IServices.IQuizService;
using MyQuiz.Domain.Entities;
using MyQuiz.Dtos.QuizDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyQuiz.Appliction.Services.QuizServiceAsync
{
    public class QuizServiceAsync : IQuizServiceAsync
    {

        private readonly IQuizRepositoryAsync quizRepositoryAsync;
        private readonly IMapper mapper;

        public QuizServiceAsync(IQuizRepositoryAsync quizRepository, IMapper mapper)
        {
            quizRepositoryAsync = quizRepository;
        }


        public async Task<QuizGetDto> AddAsync(QuizAddDto Obj)
        {
            var QuizObj = mapper.Map<Lk_Quiz>(Obj);
            var QuizObjAdded = await quizRepositoryAsync.AddObjAsync(QuizObj);
            var dataDto = mapper.Map<QuizGetDto>(QuizObjAdded);
            return dataDto;
        }

        public async Task<QuizGetDto> DeleteAsync(int id)
        {
            var QuizObj = await quizRepositoryAsync.FindAsync(a => a.Id == id);

            var QuizObjDeleted = await quizRepositoryAsync.RemoveObjAsync(QuizObj);

            var dataDto = mapper.Map<QuizGetDto>(QuizObjDeleted);

            return dataDto;
        }

        public async Task<IEnumerable<QuizGetDto>> GetAllOptionsAsync()
        {
            var data = await quizRepositoryAsync.GetAllAsync();
            var dataDto = mapper.Map<IEnumerable<QuizGetDto>>(data);
            return dataDto;
        }

        public async Task<QuizGetDto> GetByIdAsync(int id)
        {
            var data = await quizRepositoryAsync.FindAsync(a => a.Id == id);
            var dataDto = mapper.Map<QuizGetDto>(data);
            return dataDto;
        }

        public async Task<QuizGetDto> UpdateAsync( QuizUpdateDto Obj)
        {
            var data = mapper.Map<Lk_Quiz>(Obj);
            var dataUpdated = await quizRepositoryAsync.UpdateAsync(data);
            var dataDto = mapper.Map<QuizGetDto>(dataUpdated);
            return dataDto;
        }

      
        
    }
}
